let userLogado = JSON.parse(localStorage.getItem('userLogado')) 

let logado = document.querySelector('#logado')
logado.innerHTML = `Olá ${userLogado.nome}`

if(localStorage.getItem('token','userLogado') == null){
  alert('Você precisa estar logado para acessar essa página')
  window.location.href = './signin.html';
}

function PrestarServico(){
  window.location.href ='./cadastrodeservicos.html' 
}

function Contrate(){
  window.location.href = './pesquisaservicos.html'
}


function sair(){
  localStorage.removeItem('token')
  localStorage.removeItem('userLogado')
  window.location.href = './signin.html'
}
