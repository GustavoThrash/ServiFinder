
const form = document.querySelector('form');


if (localStorage.getItem('servicos')) {
  const servicos = JSON.parse(localStorage.getItem('servicos'));
  const ultimoServico = servicos[servicos.length - 1];
  document.getElementById('nome').value = ultimoServico.nome;
  document.getElementById('descricao').value = ultimoServico.descricao;
  document.getElementById('cidade').value = ultimoServico.cidade;
  document.getElementById('telefone').value = ultimoServico.telefone;
}


function cadastrar(event) {
  
  event.preventDefault();

  const nome = document.getElementById('nome').value;
  const descricao = document.getElementById('descricao').value;
  const cidade = document.getElementById('cidade').value;
  const telefone = document.getElementById('telefone').value;

  const servicos = JSON.parse(localStorage.getItem('servicos')) || [];

 
  servicos.push({
    nome: nome,
    descricao: descricao,
    cidade: cidade,
    telefone: telefone
  });

  localStorage.setItem('servicos', JSON.stringify(servicos));


  const mensagem = document.createElement('p');
  mensagem.textContent = 'Serviço cadastrado com sucesso!';
  form.appendChild(mensagem);


  window.location.href = './teladelogin.html';
}


form.addEventListener('submit', cadastrar);